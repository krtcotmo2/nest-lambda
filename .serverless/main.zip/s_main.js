
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'kurtgithub',
  applicationName: 'aws-nest',
  appUid: '5pLpBwTLGjQWWyLbvg',
  orgUid: 'b34bf5bc-e783-4e47-a1f5-f9f0b8505c6b',
  deploymentUid: 'ef509c91-5c95-48ac-87fd-e34e675a6573',
  serviceName: 'aws-nest',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '7.1.0',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'aws-nest-dev-main', timeout: 6 };

try {
  const userHandler = require('./src/lambda.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}